# Infojobs for B2B

A Pen created on CodePen.io. Original URL: [https://codepen.io/Linxuan-Qiu/pen/NPKRYEJ](https://codepen.io/Linxuan-Qiu/pen/NPKRYEJ).

